# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Github: https://github.com/moedje/
# Updated on: August 2019
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import ssl, re, os, sys
try:
    import xbmc, xbmcplugin
except:
    import Kodistubs.xbmc as xbmc
    import Kodistubs.xbmcplugin as xbmcplugin
from resources.lib import newtumbl, urlquick, simpleplugin
handle = int(sys.argv[1])
path = os.path
ssl._create_default_https_context = ssl._create_unverified_context
plugin = simpleplugin.Plugin()
__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
__next__ = path.join(xbmc.translatePath('special://home/addons/{0}/resources/'.format(plugin.id)), 'next.png')
__search__ = __next__.replace('next', 'search')

API = newtumbl.newTumbl(datadir=__datadir__)


@plugin.action()
def root():
    plugin.set_setting('nosearch', False)
    tagnamelast = plugin.get_setting('lastsearch')
    rootmenu = {
        "Home": [
            {'label': 'Dashboard Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_dashboard")},
            {'label': 'Liked/Favorites', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_liked")},
            {'label': 'Search Tagged Videos', 'thumb': __search__, 'icon': __search__, 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="prompt_tag")},
            {'label': 'Gay Tagged Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_tag", tagname='gay')},
            {'label': 'Find Blogs', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="find_blogs")},
            {'label': 'Followed Blogs (Not Implemented Yet)', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_blogsfollowed")}
        ]
    }
    xbmc.executebuiltin("Container.SetViewMode(51)")
    return rootmenu["Home"]


@plugin.action()
def get_blogsfollowed():
    return []

@plugin.action()
def get_liked():
    litems = []
    items = API.getLikedPosts(pagenum=0)
    xbmc.executebuiltin("Container.SetViewMode(50)")
    for item in items:
        litems.append(addDownload(item))
    return litems


@plugin.action()
def get_dashboard():
    litems = []
    items = API.getDashPosts()
    xbmc.executebuiltin("Container.SetViewMode(50)")
    for item in items:
        litems.append(addDownload(item))
    return litems


@plugin.action()
def get_tag(params):
    litems = []
    if params.tagname is not None:
        tag = params.tagname
    else:
        tag = "gay"
    items = API.getVidsTag(tagname=tag)
    for item in items:
        litems.append(addDownload(item))
    xbmc.executebuiltin("Container.SetViewMode(50)")
    #plugin.log(msg=str(items[:]), level=xbmc.LOGINFO)
    plugin.set_setting('nosearch', True)
    return litems


@plugin.action()
def search_blogs():
    txt = get_input(settingid='lastblogsearch')
    #xbmcplugin.addDirectoryItems(handle, items=find_blogs(params="keyword="+txt.replace(' ', '+')))
    #xbmcplugin.endOfDirectory(int(handle), succeeded=True, updateListing=False)
    plugin.set_setting('nosearch', True)
    return dofind_blogs(txt)


@plugin.action()
def find_blogs():
    litems = []
    txt = ''
    txt = get_input(settingid='lastblogsearch')
    bloglist = API.SearchForBlog(keyword=txt)
    for item in bloglist:
        #url = item.get('url')
        #blogix = url.rpartition('/')[-1]
        #url = url.replace('/'+blogix,'')
        blogix = item.get("properties", {}).get("blogix", "")
        url = plugin.get_url(action="view_blog", blogid=blogix)
        ctx = [('Follow Blog', 'RunPlugin("{0}")'.format(plugin.get_url(action='follow_blog', blogid=blogix)),)]
        item.update({"context_menu": ctx, "url": url})
        litems.append(item)
    xbmc.executebuiltin("Container.SetViewMode(50)")
    plugin.set_setting('nosearch', True)
    return litems


def dofind_blogs(keyword=""):
    litems = []
    bloglist = API.SearchForBlog(keyword=keyword)
    for item in bloglist:
        blogix = item.get("properties", {}).get("blogix", "")
        url = plugin.get_url(action="view_blog", blogid=blogix)
        ctx = [('Follow Blog', 'RunPlugin("{0}")'.format(plugin.get_url(action='follow_blog', blogid=blogix)),)]
        item.update({"context_menu": ctx, "url": url})
        litems.append(item)
    xbmc.executebuiltin("Container.SetViewMode(50)")
    plugin.set_setting('nosearch', True)
    return litems


@plugin.action()
def view_blog(params):
    blogix = 0
    if params.blogid is not None:
        blogix = params.blogid
    litems = []
    blogposts = []
    blogposts = API.getBlogPosts(blogid=blogix, pagenum=0)
    for item in blogposts:
        litems.append(addDownload(item))
    #for post in blogposts:
    #    postid = post.get('properties', {}).get('postix', 0)
    #    ctx = [("Like Post", 'RunPlugin("{0}")'.format(plugin.url(action='like_post', postix=postid)))]
    #    post.update({"context_menu": ctx})
    #    litems.append(post)
    xbmc.executebuiltin("Container.SetViewMode(50)")
    plugin.set_setting('nosearch', True)
    return litems


@plugin.action()
def follow_blog(params):
    blogix = 0
    if params.blogid is not None:
        blogix = params.blogid
    API.FollowBlog(blogix)
    showMessage(header="NewTumbl", msg="Blog Followed: " + str(blogix))


@plugin.action()
def prompt_tag():
    txt = ''
    txt = get_input(settingid='lastsearch')
    xbmc.executebuiltin("Container.SetViewMode(50)")
    plugin.set_setting('nosearch', True)
    return API.getVidsTag(tagname=txt)


def addDownload(item):
    ctxlist = []
    ctxlist = item.get('context_menu', [])
    ctx = ("Download", 'RunPlugin("{0}")'.format(plugin.get_url(action="download", video=item.get('url', ''))),)
    ctxlist.append(ctx)
    item.update({"context_menu": ctxlist})
    return item


@plugin.action()
def download(params):
    vurl = ''
    vurl = params.video
    try:
        from YDStreamExtractor import getVideoInfo
        from YDStreamExtractor import handleDownload
        info = getVideoInfo(vurl, resolve_redirects=True)
        dlpath = plugin.get_setting('downloadpath')
        if not path.exists(dlpath):
            dlpath = xbmc.translatePath("home://")
        handleDownload(info, bg=True, path=dlpath)
    except:
        plugin.notify(vurl, "Download Failed")

def showMessage(self, header='', msg=''):
    try:
        header = str(header.encode('utf-8', 'ignore'))
        msg = str(msg.encode('utf-8', 'ignore'))
        xbmc.executebuiltin('Notification({0},{1})'.format(header, msg))
    except:
        print(header + '\n' + msg)


def get_input(default='', settingid='lastsearch'):
    if default=='':
        default = plugin.get_setting(settingid)
    if plugin.get_setting('nosearch', convert=True):
        return default
    kb = xbmc.Keyboard(default, 'Search NewTumbl')
    kb.setDefault(default)
    kb.setHeading('NewTumbl')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term = kb.getText()
        plugin.set_setting(settingid, search_term)
        return(search_term)
    else:
        return None

if __name__ == '__main__':
    # Run our plugin
    userid = plugin.get_setting('userid')
    usertoken = plugin.get_setting('usertoken')
    API.UserId = userid
    API.UserToken = usertoken
    plugin.run()
    xbmcplugin.setContent(handle, 'episodes')
    xbmcplugin.setPluginCategory(handle, 'porn')
    #xbmc.executebuiltin("Container.SetViewMode(50)")
    #xbmc.executebuiltin('Skin.SetBool(SkinHelper.EnableAnimatedPosters)')