# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Github: https://github.com/moedje/
# Updated on: August 2019
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import ssl, re, os, sys
try:
    import xbmc, xbmcplugin
except:
    import Kodistubs.xbmc as xbmc
    import Kodistubs.xbmcplugin as xbmcplugin
from resources.lib import newtumbl, urlquick, simpleplugin
handle = int(sys.argv[1])
path = os.path
ssl._create_default_https_context = ssl._create_unverified_context
plugin = simpleplugin.Plugin()
__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
__next__ = path.join(xbmc.translatePath('special://home/addons/{0}/resources/'.format(plugin.id)), 'next.png')
__search__ = __next__.replace('next', 'search')

API = newtumbl.newTumbl(datadir=__datadir__)


@plugin.action()
def root():
    tagnamelast = plugin.get_setting('lastsearch')
    rootmenu = {
        "Home": [
            {'label': 'Dashboard Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_dashboard")},
            {'label': 'Search Tagged Videos', 'thumb': __search__, 'icon': __search__, 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="prompt_tag")},
            {'label': 'Gay Tagged Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_tag", tagname='gay')}
        ]
    }
    return rootmenu["Home"]


@plugin.action()
def get_dashboard():
    items = API.getDashPosts()
    #plugin.log(msg=str(items[:]), level=xbmc.LOGINFO)
    return items


@plugin.action()
def get_tag(params):
    if params.tagname is not None:
        tag = params.tagname
    else:
        tag = "public"
    items = API.getVidsTag(tagname=tag)
    #plugin.log(msg=str(items[:]), level=xbmc.LOGINFO)
    return items


@plugin.action()
def prompt_tag():
    txt = ''
    txt = plugin.get_setting('lastsearch')
    txt = get_input(default=txt)
    return API.getVidsTag(tagname=txt)


@plugin.action()
#@plugin.mem_cached(10)
def root2():
    imgVidster = __next__.replace('next', 'myvidster')
    vidsterNameChan = 'GayPublic'
    lblTpl = '[COLOR green]{0}[/COLOR] ([COLOR white][I]{1}[/I][/COLOR])\n[COLOR yellow]{2}[/COLOR]'
    lblVidsterNew = lblTpl.format('MyVidster', 'Latest', vidsterNameChan)
    lblVidsterChan = lblTpl.format('MyVidster', 'View Channel', vidsterNameChan) #'[COLOR green]MyVidster[/COLOR] - [COLOR white][I]View Channel[/I][/COLOR]\n[COLOR yellow]{0}[/COLOR]'.format(vidsterNameChan)
    lblVidsterGetChan = lblTpl.format('MyVidster Channel', vidsterNameChan, '')
    lblWs = lblTpl.format("Watch Series", "Latest", "")
    lblWsAll = lblTpl.format("Watch Series", "Full List", "")
    rootmenu = {
        "Home": [
            {'label': lblVidsterGetChan, 'url': plugin.get_url(action='get_channel', id=1533786, page=1), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False},
            {'label': lblVidsterNew, 'url': plugin.get_url(action='home_myvidster', id=1533786), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False},             
            {'label': lblVidsterChan, 'url': plugin.get_url(action='list_vidster', id=1533786), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False},
            {'label': "Search MyVidster", 'url': plugin.get_url(action='search_vidster', query="public"), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False}]
    }
    return rootmenu["Home"]


@plugin.action()
def download(params):
    vurl = ''
    vurl = params.video
    try:
        from YDStreamExtractor import getVideoInfo
        from YDStreamExtractor import handleDownload
        info = getVideoInfo(vurl, resolve_redirects=True)
        dlpath = plugin.get_setting('downloadpath')
        if not path.exists(dlpath):
            dlpath = xbmc.translatePath("home://")
        handleDownload(info, bg=True, path=dlpath)
    except:
        plugin.notify(vurl, "Download Failed")


def showMessage(self, header='', msg=''):
    try:
        header = str(header.encode('utf-8', 'ignore'))
        msg = str(msg.encode('utf-8', 'ignore'))
        xbmc.executebuiltin('Notification({0},{1})'.format(header, msg))
    except:
        print(header + '\n' + msg)


def get_input(default=''):
    kb = xbmc.Keyboard(default, 'Search MyVidster')
    kb.setDefault(default)
    kb.setHeading('MyVidster Search')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term = kb.getText()
        return(search_term)
    else:
        return None

if __name__ == '__main__':
    # Run our plugin
    plugin.run()
    xbmcplugin.setContent(handle, 'episodes')
    xbmcplugin.setPluginCategory(handle, 'porn')
    xbmc.executebuiltin('Skin.SetBool(SkinHelper.EnableAnimatedPosters)')